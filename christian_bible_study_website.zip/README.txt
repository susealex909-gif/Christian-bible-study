CHRISTIAN BIBLE STUDY WEBSITE

1. Open index.html in a browser to preview the website.
2. Replace the placeholder email, location, and meeting time in index.html.
3. To publish online, upload index.html and hero.png to a static hosting service.
4. The contact form is a demonstration; connect it to an email/form service before publishing.
